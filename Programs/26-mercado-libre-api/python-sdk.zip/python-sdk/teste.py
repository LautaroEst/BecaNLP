import sys
sys.path.append('../lib')
from meli import Meli
